﻿using System;
using System.IO;
using System.Windows.Forms;

namespace 示例例子
{
    /// <summary>
    /// 文本框自动保存/加载管理器（兼容 VS2012）
    /// 自动保存 TextBox 内容到 C:\程序名\TextBoxName.txt
    /// </summary>
    public class TextBoxAutoSaveManager
    {
        private string saveFolder;

        /// <summary>
        /// 初始化并绑定窗体中所有 TextBox 的自动保存功能
        /// </summary>
        /// <param name="form">要处理的窗体</param>
        public void Initialize(Form form)
        {
            if (form == null) return;

            // 获取程序名作为文件夹名
            string exePath = Application.ExecutablePath;
            string exeFileName = Path.GetFileNameWithoutExtension(exePath);
            saveFolder = @"C:\cctxt\" + exeFileName; // 用拼接，避免 Path.Combine 多余反斜杠

            // 创建目录（如果不存在）
            if (!Directory.Exists(saveFolder))
            {
                try
                {
                    Directory.CreateDirectory(saveFolder);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("无法创建保存目录: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // 遍历窗体中所有 TextBox（包括嵌套的）
            FindAndHookTextBoxes(form);
        }

        /// <summary>
        /// 递归查找控件并绑定事件
        /// </summary>
        /// <param name="parent">父控件</param>
        private void FindAndHookTextBoxes(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is TextBox)
                {
                    TextBox textBox = (TextBox)control; // 先转换

                    // 绑定变化事件
                    textBox.TextChanged += (sender, e) =>
                    {
                        SaveTextBoxContent(textBox);
                    };

                    // 加载已有内容
                    LoadTextBoxContent(textBox);
                }
                else if (control.HasChildren)
                {
                    FindAndHookTextBoxes(control); // 递归
                }
            }
        }

        /// <summary>
        /// 保存单个 TextBox 的内容
        /// </summary>
        /// <param name="tb">TextBox 控件</param>
        private void SaveTextBoxContent(TextBox tb)
        {
            if (tb == null || string.IsNullOrEmpty(saveFolder)) return;

            string filePath = saveFolder + "\\" + tb.Name + ".txt"; // 字符串拼接

            try
            {
                File.WriteAllText(filePath, tb.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败: " + ex.Message);
            }
        }

        /// <summary>
        /// 加载 TextBox 的内容（如果存在）
        /// </summary>
        /// <param name="tb">TextBox 控件</param>
        private void LoadTextBoxContent(TextBox tb)
        {
            if (tb == null || string.IsNullOrEmpty(saveFolder)) return;

            string filePath = saveFolder + "\\" + tb.Name + ".txt"; // 字符串拼接

            if (File.Exists(filePath))
            {
                try
                {
                    tb.Text = File.ReadAllText(filePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("读取失败: " + ex.Message);
                }
            }
        }
    }
}