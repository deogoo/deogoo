﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace 示例例子
{
    /// <summary>
    /// 列表框自动保存/加载管理器
    /// 自动保存 ListBox 内容到 C:\程序名\ListBoxName.txt
    /// </summary>
    public class ListBoxAutoSaveManager
    {
        private string saveFolder;

        /// <summary>
        /// 初始化并绑定窗体中所有 ListBox 的自动保存功能
        /// </summary>
        /// <param name="form">要处理的窗体</param>
        public void Initialize(Form form)
        {
            if (form == null) return;

            // 获取程序名作为文件夹名
            string exePath = Application.ExecutablePath;
            string exeFileName = Path.GetFileNameWithoutExtension(exePath);
            saveFolder = @"C:\cctxt\" + exeFileName; // 拼接

            // 创建目录（如果不存在）
            if (!Directory.Exists(saveFolder))
            {
                try
                {
                    Directory.CreateDirectory(saveFolder);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("无法创建保存目录: " + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
            }

            // 遍历窗体中所有 ListBox（包括嵌套的）
            FindAndHookListBoxes(form);
        }

        /// <summary>
        /// 递归查找控件并绑定事件
        /// </summary>
        private void FindAndHookListBoxes(Control parent)
        {
            foreach (Control control in parent.Controls)
            {
                if (control is ListBox)
                {
                    ListBox listBox = (ListBox)control;

                    // 绑定事件（项目变化时保存）
                    listBox.SelectedIndexChanged += (sender, e) =>
                    {
                        SaveListBoxContent(listBox);
                    };
                    listBox.DataSourceChanged += (sender, e) =>
                    {
                        SaveListBoxContent(listBox);
                    };

                    // 加载已有内容
                    LoadListBoxContent(listBox);
                }
                else if (control.HasChildren)
                {
                    FindAndHookListBoxes(control); // 递归
                }
            }
        }

        /// <summary>
        /// 保存单个 ListBox 的内容
        /// </summary>
        private void SaveListBoxContent(ListBox lb)
        {
            if (lb == null || string.IsNullOrEmpty(saveFolder)) return;

            string filePath = saveFolder + "\\" + lb.Name + ".txt"; // 拼接

            try
            {
                StringBuilder sb = new StringBuilder();
                foreach (var item in lb.Items)
                {
                    sb.AppendLine(item.ToString());
                }
                File.WriteAllText(filePath, sb.ToString());
            }
            catch (Exception ex)
            {
                MessageBox.Show("保存失败: " + ex.Message);
            }
        }

        /// <summary>
        /// 加载 ListBox 的内容（如果存在）
        /// </summary>
        private void LoadListBoxContent(ListBox lb)
        {
            if (lb == null || string.IsNullOrEmpty(saveFolder)) return;

            string filePath = saveFolder + "\\" + lb.Name + ".txt";

            if (File.Exists(filePath))
            {
                try
                {
                    string[] lines = File.ReadAllLines(filePath);
                    lb.Items.Clear();
                    lb.Items.AddRange(lines);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("读取失败: " + ex.Message);
                }
            }
        }
    }
}
