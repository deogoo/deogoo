﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;

public static class EncryptHelper
{
    private static readonly string AES_Key = "A1B2C3D4E5F6G7H8";
    private static readonly string AES_IV = "1H2G3F4E5D6C7B8A";

    // AES 加密
    public static string Encrypt(string plainText)
    {
        if (string.IsNullOrEmpty(plainText)) return string.Empty;

        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(AES_Key);
            aes.IV = Encoding.UTF8.GetBytes(AES_IV);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using (MemoryStream ms = new MemoryStream())
            using (ICryptoTransform encryptor = aes.CreateEncryptor())
            using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
            {
                byte[] bytes = Encoding.UTF8.GetBytes(plainText);
                cs.Write(bytes, 0, bytes.Length);
                cs.FlushFinalBlock();
                string base64 = Convert.ToBase64String(ms.ToArray());

                // URL 安全 Base64：+ -> -, / -> _, 去掉尾部 =
                return base64.Replace("+", "-").Replace("/", "_").TrimEnd('=');
            }
        }
    }

    // AES 解密
    public static string Decrypt(string cipherText)
    {
        if (string.IsNullOrEmpty(cipherText)) return string.Empty;

        // 还原 Base64：- -> +, _ -> /, 补齐 =
        string base64 = cipherText.Replace("-", "+").Replace("_", "/");
        int padding = 4 - (base64.Length % 4);
        if (padding < 4)
            base64 = base64.PadRight(base64.Length + padding, '=');

        byte[] bytes = Convert.FromBase64String(base64);

        using (Aes aes = Aes.Create())
        {
            aes.Key = Encoding.UTF8.GetBytes(AES_Key);
            aes.IV = Encoding.UTF8.GetBytes(AES_IV);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            using (MemoryStream ms = new MemoryStream())
            using (ICryptoTransform decryptor = aes.CreateDecryptor())
            using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Write))
            {
                cs.Write(bytes, 0, bytes.Length);
                cs.FlushFinalBlock();
                return Encoding.UTF8.GetString(ms.ToArray());
            }
        }
    }
}
