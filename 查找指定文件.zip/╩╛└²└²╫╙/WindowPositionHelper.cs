﻿using System;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

namespace 示例例子
{
    public static class WindowPositionHelper
    {
        private const string RootTxtPath = @"C:\cctxt\";
        private const string PositionTxtName = "WindowPosition.txt";
        private static string _currentProjectName;

        public static void InitWindowPositionMemory(this Form form)
        {
            if (form == null) return;

            string projectName = GetCurrentProjectName() ?? "DefaultWinFormProject";

            form.Load += (s, e) => RestoreWindowPosition(form, projectName);
            form.FormClosing += (s, e) => SaveWindowPosition(form, projectName);
        }

        private static string GetCurrentProjectName()
        {
            if (!string.IsNullOrEmpty(_currentProjectName))
                return _currentProjectName;

            try
            {
                Assembly entryAssembly = Assembly.GetEntryAssembly();
                if (entryAssembly != null)
                {
                    _currentProjectName = entryAssembly.GetName().Name;
                }
                else
                {
                    _currentProjectName = Assembly.GetExecutingAssembly().GetName().Name;
                }
                return _currentProjectName;
            }
            catch
            {
                return null;
            }

        }

        private static void RestoreWindowPosition(Form form, string projectName)
        {
            try
            {
                string path = GetTxtFilePath(projectName, PositionTxtName);
                if (!File.Exists(path)) return;

                string[] data = File.ReadAllLines(path);
                if (data.Length >= 2)
                {
                    int left = ParseInt(data[0], form.Left);
                    int top = ParseInt(data[1], form.Top);

                    // 验证是否在屏幕可视区域
                    if (IsWindowInScreenBounds(left, top))
                    {
                        form.Left = left;
                        form.Top = top;
                    }
                }
            }
            catch { }
        }

        private static void SaveWindowPosition(Form form, string projectName)
        {
            try
            {
                string path = GetTxtFilePath(projectName, PositionTxtName);
                string dir = Path.GetDirectoryName(path);
                if (!Directory.Exists(dir))
                    Directory.CreateDirectory(dir);

                string[] data = { form.Left.ToString(), form.Top.ToString() };
                File.WriteAllLines(path, data);
            }
            catch { }
        }

        private static string GetTxtFilePath(string projectName, string txtFileName)
        {
            string safeProjectName = SanitizeFileName(projectName);
            string txtDir = Path.Combine(RootTxtPath, safeProjectName);
            return Path.Combine(txtDir, txtFileName);
        }

        private static string SanitizeFileName(string fileName)
        {
            foreach (char c in Path.GetInvalidFileNameChars())
                fileName = fileName.Replace(c, '_');
            return fileName;
        }

        private static int ParseInt(string str, int defaultValue)
        {
            int result;
            if (int.TryParse(str, out result))
            {
                return result;
            }
            else
            {
                return defaultValue;
            }
        }


        private static bool IsWindowInScreenBounds(int left, int top)
        {
            foreach (Screen screen in Screen.AllScreens)
            {
                if (screen.Bounds.Contains(left, top))
                    return true;
            }
            return false;
        }
    }
}
