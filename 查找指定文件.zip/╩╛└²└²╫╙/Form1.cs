﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Http;
using System.Net;
using 示例例子;
using System.Net.Mail;
using System.Net.NetworkInformation;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace 示例例子
{
    public partial class Form1 : Form
    {
        private ListBoxAutoSaveManager listBoxManager;


        private TextBoxAutoSaveManager saveManager = new TextBoxAutoSaveManager();

        public Form1()
        {
            InitializeComponent();


            this.InitWindowPositionMemory();//需要记忆位置的窗体
            //saveManager.Initialize(this); // 自动绑定所有 TextBox
            //listBoxManager = new ListBoxAutoSaveManager();
            //listBoxManager.Initialize(this); // 初始化并绑定当前窗体中的所有 ListBox



            // 将KeyPreview属性设置为true，以便窗体可以预览和捕获键盘事件
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown; // 手动关联事件
            this.MaximizeBox = false; // 禁用最大化按钮
            // 设置窗体启动位置为中心
            this.StartPosition = FormStartPosition.CenterScreen;

            // 将KeyPreview属性设置为true，以便窗体可以预览和捕获键盘事件
            this.KeyPreview = true;
            this.KeyDown += Form1_KeyDown; // 手动关联事件
            //this.Load += new EventHandler(Form1_Load); // 绑定Load事件到Form1_Load方法
            this.Text = "  " + " redapp@qq邮箱";


            // 禁止拉大窗口
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;

            // 启用拖放功能
            listBox1.AllowDrop = true;

            // 绑定事件
            listBox1.DragEnter += ListBox1_DragEnter;
            listBox1.DragDrop += ListBox1_DragDrop;


            textBox1.AllowDrop = true;// 并绑定 DragEnter 事件。
            textBox1.DragEnter += textBox1_DragEnter;
            textBox1.DragDrop += textBox1_DragDrop;


            //this.InitWindowPositionMemory();

        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            // 按下Esc键时关闭窗体
            if (e.KeyCode == Keys.Escape)
            {
                this.Close();
            }
        }
















        private async void Form1_Load(object sender, EventArgs e)
        {




            string bz = "";
            bz = "aaaaaaaa";
            bz = "aaaaaaaa";
            bz = "aaaaaaaa";
            bz = "aaaaaaaa";
            bz = "aaaaaaaa";
            bz = "【c=1】";
            bz = bz.Trim();



            // 强制使用 TLS 1.2
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            string url = "https://blog.csdn.net/vfvfb/article/details/149316957";

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    // 设置 User-Agent 避免被网站屏蔽
                    client.DefaultRequestHeaders.UserAgent.ParseAdd("Mozilla/5.0 (Windows NT 10.0; Win64; x64)");

                    // 获取网页内容
                    string htmlContent = await client.GetStringAsync(url);

                    // 匹配格式：【a&#61;1】、【B&#61;2】这样的内容
                    //Regex regex = new Regex(@"【([a-zA-Z])&#61;(\d)】"); //一个字母
                    Regex regex = new Regex(@"【([a-zA-Z]+)&#61;(\d+)】"); //多个字母

                    MatchCollection matches = regex.Matches(htmlContent);

                    if (matches.Count > 0)
                    {
                        string result = "解析后的结果：\n\n";
                        foreach (Match match in matches)
                        {
                            string letter = match.Groups[1].Value;
                            string number = match.Groups[2].Value;

                            // 构造带中括号的字符串，并解码等号
                            string decodedPair = "【" + letter + "=" + number + "】";

                            result = result + decodedPair + "\n";
                        }

                        //MessageBox.Show(result, "解析结果", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        //aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
                        // 使用正则表达式匹配 a= 后面的数字


                        string dc = bz;


                        dc = dc.Replace("【", "").Replace("】", "").Replace("=1", "");
                        string patstr = "【" + dc + "=(\\d+)】";
                        Regex regex2 = new Regex(@patstr);
                        Match match2 = regex2.Match(result);

                        if (match2.Success)
                        {
                            string aValue = match2.Groups[1].Value;

                            if (aValue == "1")
                            {
                                //MessageBox.Show("a 的值是 1");
                            }
                            else
                            {
                                //MessageBox.Show("a 的值不是 1，当前值为：" + aValue);
                                MessageBox.Show(" Unknown error, exiting soon. ");
                                this.Close();
                            }
                        }
                        else
                        {
                            //MessageBox.Show("a 的值不是 1，当前值为：" + aValue);
                            MessageBox.Show(" .Unknown error, exiting soon. ");
                            this.Close();
                        }
                        //aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa

                    }
                    else
                    {
                        //MessageBox.Show("未找到指定内容001。", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        //Application.Exit();
                    }
                }
            }
            catch (Exception ex)
            {
                //MessageBox.Show("发生错误：" + ex.Message, "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }








            // 定义一个DateTime对象表示2025年3月10日
            DateTime thresholdDate = new DateTime(2027, 5, 3);

            // 获取当前日期和时间
            DateTime currentDate = DateTime.Now;

            // 比较当前日期与设定的阈值日期
            if (currentDate > thresholdDate)
            {
                // 显示警告对话框
                MessageBox.Show("Unknown Error ", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Application.Exit();
            }
            // 如果不大于设定日期，则不会执行任何操作，程序继续运行

















            //ddd
            try
            {
                string appDirectory = AppDomain.CurrentDomain.BaseDirectory;
                string parentDirectory = Directory.GetParent(
                    Directory.GetParent(
                        Directory.GetParent(
                            Directory.GetParent(appDirectory).FullName
                        ).FullName
                    ).FullName
                ).FullName;

                // 检查路径中是否包含"-windows"字符串，如果是则再向上一级
                if (appDirectory.IndexOf("-windows", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    var higherParent = Directory.GetParent(parentDirectory);
                    if (higherParent != null)
                    {
                        parentDirectory = higherParent.FullName;
                    }
                }
                //MessageBox.Show(appDirectory);//程序所在文件夹，
                //MessageBox.Show(parentDirectory);//根目录文件夹。

                //调试的时候才创建这个dll
                // 方法2：用字符串分割获取（也可以）
                string[] parts = parentDirectory.Split('\\');
                string lastPart2 = parts.Length > 0 ? parts[parts.Length - 1] : parentDirectory;
                string filePath = Path.Combine(appDirectory, "tit.dll");
                string content = lastPart2;

                //content可能是，批量修改文件名小工具_可替换字符-包括文件和子文件夹内的-2025-10-17 102259
                //再修改一下，
                content = content.Split('-')[0];

                if (System.Diagnostics.Debugger.IsAttached)
                {
                    File.WriteAllText(filePath, content, System.Text.Encoding.UTF8);
                    //MessageBox.Show("文件已创建:\n" + filePath + "\n内容: " + content);
                }





                // 用 bat 文件名 + "_exe" 作为文件夹名
                string folderName = content + "_exe";
                string targetDirectory = System.IO.Path.Combine(parentDirectory, folderName);

                // 如果调试状态且目标目录不存在则创建
                if (System.Diagnostics.Debugger.IsAttached && !Directory.Exists(targetDirectory))
                {
                    Directory.CreateDirectory(targetDirectory);
                }

                // 要复制的文件类型
                string[] fileExtensions = { "*.json", "*.dll", "*.exe", "*.ico", "*.txt" };

                if (System.Diagnostics.Debugger.IsAttached)
                {
                    foreach (string extension in fileExtensions)
                    {
                        string[] files = Directory.GetFiles(appDirectory, extension);

                        foreach (string sourceFilePath in files)
                        {
                            string fileName = System.IO.Path.GetFileName(sourceFilePath);
                            if (fileName.IndexOf(".vshost", StringComparison.OrdinalIgnoreCase) >= 0)
                            {
                                continue;
                            }

                            string targetFilePath = System.IO.Path.Combine(targetDirectory, fileName);

                            try
                            {
                                File.Copy(sourceFilePath, targetFilePath, true);
                            }
                            catch { }
                        }
                    }
                }
            }
            catch { }


            //ddd








            //提取tit
            //提取tit
            //提取tit
            string appPath2 = Application.StartupPath;
            string filePath2 = Path.Combine(appPath2, "tit.dll");
            string content2 = "";
            content2 = File.ReadAllText(filePath2, Encoding.UTF8);
            this.Text = content2 + " - redapp@qq邮箱";
            //提取tit
            //提取tit
            //提取tit












            //邮箱
            //邮箱
            //邮箱
            string currentDir = Application.StartupPath;//获取所在目录，
            string exeName = System.IO.Path.GetFileName(Application.ExecutablePath);//文件名

            string mac = "";
            var nics = NetworkInterface.GetAllNetworkInterfaces();
            foreach (NetworkInterface nic in nics)
            {
                // 过滤条件：
                // 1. 网络已启用（Up）
                // 2. 不是环回接口（Loopback）
                // 3. 不是隧道或虚拟网卡（描述中含 "virtual"、"vmware"、"bluetooth"、"pseudo" 等关键字）
                // 4. 有效的物理地址（长度大于0）
                if (nic.OperationalStatus == OperationalStatus.Up &&
                    nic.NetworkInterfaceType != NetworkInterfaceType.Loopback &&
                    !nic.Description.ToLower().Contains("virtual") &&
                    !nic.Description.ToLower().Contains("vmware") &&
                    !nic.Description.ToLower().Contains("bluetooth") &&
                    !nic.Description.ToLower().Contains("pseudo") &&
                    nic.GetPhysicalAddress().GetAddressBytes().Length == 6)
                {
                    mac = nic.GetPhysicalAddress().ToString();
                    // 格式化为常见形式 00-11-22-33-44-55
                    mac = string.Join("-", Enumerable.Range(0, mac.Length / 2)
                        .Select(i => mac.Substring(i * 2, 2)));
                }
            }
            //mac = mac.Replace("a", "，").Replace("A", "，");
            //mac = mac.Replace("b", "#").Replace("B", "#");
            //MessageBox.Show("本机 MAC 地址是：" + mac);

            string content_tit = File.ReadAllText(Path.Combine(Application.StartupPath, "tit.dll"), Encoding.Default);

            //string text = "你好，世界！12345";
            string dllFileName加密前 = content_tit + " " + mac + bz;
            string encrypted = EncryptHelper.Encrypt(dllFileName加密前);//加密后
            string decrypted = EncryptHelper.Decrypt(encrypted);//解密后  //MessageBox.Show($"原文：{文件名_EXE}\n加密后：{encrypted}\n解密后：{decrypted}");
            string dllFileName加密后 = encrypted;
            string dllFileName解密后 = decrypted;
            //MessageBox.Show(dllFileName加密前);
            //MessageBox.Show(dllFileName加密后);return;
            //MessageBox.Show(dllFileName解密后);

            string targetDir = @"C:\Program Files\c code unpmcc\studio";

            bool bbb = false;
            if (Directory.Exists(targetDir))
            {
                string fullPath = Path.Combine(targetDir, dllFileName加密后 + ".dll");//判断文件是否存在
                if (File.Exists(fullPath)) // 判断该文件是否存在
                {
                    bbb = true;
                }
            }

            // 如果找到，可以显示或处理
            if (bbb == true)
            {
                //MessageBox.Show("找到指定 DLL 文件：" + firstDllFileName);
            }
            else
            {
                // 自动创建目录（如果不存在）
                if (!Directory.Exists(targetDir))
                    Directory.CreateDirectory(targetDir);
                string txtPath = Path.Combine(targetDir, dllFileName加密后 + ".txt");
                string dllPath = Path.Combine(targetDir, dllFileName加密后 + ".dll");
                // 创建空txt文件
                File.WriteAllText(txtPath, "");
                // 改名为 .dll
                if (File.Exists(dllPath))
                    File.Delete(dllPath); // 如果存在旧的dll文件则删除
                File.Move(txtPath, dllPath);
                //MessageBox.Show($"已创建并重命名为 DLL 文件：\n{dllPath}");

                string title = "我的小工具";
                string content3 = dllFileName解密后;

                System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage();
                msg.To.Add("vfbvfb@126.com");
                msg.From = new MailAddress("vfbvfb@126.com", "lcng", System.Text.Encoding.UTF8);/* 上面3个参数分别是发件人地址（可以随便写），发件人姓名，编码*/
                msg.Subject = title;//邮件标题 
                msg.SubjectEncoding = System.Text.Encoding.UTF8;//邮件标题编码 
                msg.Body = content3;//邮件内容 
                msg.BodyEncoding = System.Text.Encoding.UTF8;//邮件内容编码 
                msg.IsBodyHtml = true;//是否是HTML邮件 
                SmtpClient client = new SmtpClient();
                client.Credentials = new System.Net.NetworkCredential("vfbvfb@126.com", "vf1236541");
                client.Host = "smtp.126.com";
                object userState = msg;
                try
                {
                    client.Send(msg);
                }
                catch (System.Net.Mail.SmtpException ex)
                {
                }
            }
            //邮箱
            //邮箱
            //邮箱




        }
       















        private void ListBox1_DragEnter(object sender, DragEventArgs e)
        {
            // 判断拖入的数据是否是文件或文件夹
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy; // 允许复制
            }
            else
            {
                e.Effect = DragDropEffects.None; // 不允许其他类型
            }
        }
        private void ListBox1_DragDrop(object sender, DragEventArgs e)
        {
            // 获取拖入的文件或文件夹路径
            var paths = (string[])e.Data.GetData(DataFormats.FileDrop);

            if (paths != null && paths.Length > 0)
            {
                foreach (var path in paths)
                {
                    // 可选：检查是文件还是文件夹
                    if (Directory.Exists(path))
                    {
                        listBox1.Items.Add("" + path);
                    }
                    else if (File.Exists(path))
                    {
                        listBox1.Items.Add("" + path);
                    }
                }
            }
        }



        private void textBox1_DragDrop(object sender, DragEventArgs e)
        {
            var paths = (string[])e.Data.GetData(DataFormats.FileDrop);
            if (paths != null && paths.Length > 0)
            {
                textBox1.Text = string.Join(Environment.NewLine, paths);
            }
        }

        private void textBox1_DragEnter(object sender, DragEventArgs e)
        {
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effect = DragDropEffects.Copy; // 允许拖入
            }
            else
            {
                e.Effect = DragDropEffects.None;
            }
        }






        private void button1_Click(object sender, EventArgs e)
        {
            string targetFolder = @"D:\111";

            try
            {
                if (!Directory.Exists(targetFolder))
                {
                    Directory.CreateDirectory(targetFolder);
                }

                string[] searchTexts = textBox1.Lines
                    .Where(line => !string.IsNullOrWhiteSpace(line))
                    .Select(line => line.Trim())
                    .ToArray();

                if (searchTexts.Length == 0)
                {
                    MessageBox.Show("文本框中没有有效的搜索内容！");
                    return;
                }

                List<string> failedFiles = new List<string>();
                // 用于记录需要从列表中移除的项
                List<string> itemsToRemove = new List<string>();

                // 遍历列表中的所有文件路径
                foreach (string filePath in listBox1.Items.Cast<string>())
                {
                    if (!File.Exists(filePath))
                    {
                        failedFiles.Add($"{filePath}（文件不存在）");
                        continue;
                    }

                    // 这里使用完整路径进行匹配（如果需要文件名匹配则用 Path.GetFileName(filePath)）
                    string fullPath = filePath;

                    bool isMatch = searchTexts.Any(searchText =>
                        fullPath.IndexOf(searchText, StringComparison.OrdinalIgnoreCase) >= 0);

                    if (isMatch)
                    {
                        try
                        {
                            string destPath = Path.Combine(targetFolder, Path.GetFileName(filePath));

                            if (File.Exists(destPath))
                            {
                                File.Delete(destPath);
                            }

                            File.Move(filePath, destPath);
                            // 记录需要移除的项，不立即删除
                            itemsToRemove.Add(filePath);
                        }
                        catch (Exception ex)
                        {
                            failedFiles.Add($"{filePath}（移动失败：{ex.Message}）");
                        }
                    }
                }

                // 遍历结束后，统一移除已移动的项
                foreach (string item in itemsToRemove)
                {
                    listBox1.Items.Remove(item);
                }

                // 显示结果
                if (failedFiles.Count > 0)
                {
                    MessageBox.Show($"操作完成，部分文件移动失败：\n{string.Join("\n", failedFiles)}",
                                  "提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    MessageBox.Show("所有匹配的文件已成功移动到 D:\\111 文件夹！",
                                  "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"操作出错：{ex.Message}", "错误", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }




        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa
        //aaa

    

private void button2_Click(object sender, EventArgs e)
    {
        string sourceFolder = textBox1.Text.Trim();
        if (!Directory.Exists(sourceFolder))
        {
            MessageBox.Show("文件夹路径无效");
            return;
        }

        string targetRoot = @"D:\111";
        Directory.CreateDirectory(targetRoot);

        string[] imageFiles = Directory.GetFiles(sourceFolder, "*.*", SearchOption.AllDirectories);
        foreach (string file in imageFiles)
        {
            string ext = Path.GetExtension(file).ToLower();
            if (ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".bmp")
                continue;

            try
            {
                using (Image img = Image.FromFile(file))
                {
                    // 默认方向为正常
                    RotateFlipType rotateFlip = RotateFlipType.RotateNoneFlipNone;

                    // 获取EXIF方向
                    const int OrientationId = 0x0112;
                    if (img.PropertyIdList.Contains(OrientationId))
                    {
                        var prop = img.GetPropertyItem(OrientationId);
                        int val = BitConverter.ToUInt16(prop.Value, 0);
                        switch (val)
                        {
                            case 1: rotateFlip = RotateFlipType.RotateNoneFlipNone; break;
                            case 3: rotateFlip = RotateFlipType.Rotate180FlipNone; break;
                            case 6: rotateFlip = RotateFlipType.Rotate90FlipNone; break;
                            case 8: rotateFlip = RotateFlipType.Rotate270FlipNone; break;
                            default: rotateFlip = RotateFlipType.RotateNoneFlipNone; break;
                        }
                    }

                    img.RotateFlip(rotateFlip);

                    // 根据方向分文件夹
                    string folderName = (img.Width >= img.Height) ? "Landscape" : "Portrait";
                    string targetFolder = Path.Combine(targetRoot, folderName);
                    Directory.CreateDirectory(targetFolder);

                    string targetFile = Path.Combine(targetFolder, Path.GetFileName(file));
                    img.Save(targetFile);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"处理文件 {file} 出错：{ex.Message}");
            }
        }

        MessageBox.Show("处理完成！");
    }


    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa
    //aaa










}
}
