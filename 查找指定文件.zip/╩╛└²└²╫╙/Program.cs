﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.Threading;

namespace 示例例子
{
    static class Program
    {
        /// <summary>
        /// 应用程序的主入口点。
        /// </summary>
        // 互斥体名称，使用唯一标识符确保不与其他程序冲突
        private static readonly string MutexName = "ExampleApp-SingleInstance-8F4D2E7C-1A3B-4C5D-6E7F-8A9B0C1D2E3F";
        private static Mutex _mutex;

        [STAThread]
        static void Main()
        {
            // 检查是否已有实例在运行
            bool createdNew;

            // 创建互斥体
            _mutex = new Mutex(true, MutexName, out createdNew);

            if (createdNew)
            {
                // 首次启动，正常运行程序
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                Application.Run(new Form1());

                // 释放互斥体
                _mutex.ReleaseMutex();
            }
            else
            {
                // 已存在运行实例，提示用户
                MessageBox.Show("应用程序已在运行中！", "提示", MessageBoxButtons.OK, MessageBoxIcon.Information);

                // 激活已运行的实例窗口
                BringExistingInstanceToFront();
            }
        }

        // 将已运行的实例窗口激活到前台
        private static void BringExistingInstanceToFront()
        {
            string currentProcessName = Process.GetCurrentProcess().ProcessName;

            foreach (Process process in Process.GetProcessesByName(currentProcessName))
            {
                if (process.Id != Process.GetCurrentProcess().Id)
                {
                    IntPtr mainWindowHandle = process.MainWindowHandle;
                    if (mainWindowHandle != IntPtr.Zero)
                    {
                        ShowWindow(mainWindowHandle, SW_RESTORE);
                        SetForegroundWindow(mainWindowHandle);
                        break;
                    }
                }
            }
        }

        // Windows API导入
        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool SetForegroundWindow(IntPtr hWnd);

        [System.Runtime.InteropServices.DllImport("user32.dll")]
        private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

        private const int SW_RESTORE = 9;
    }
}
